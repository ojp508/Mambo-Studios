﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class enemycontrol : MonoBehaviour {
	private Rigidbody2D rb;
	private GameObject grid;
	private int speed;
	// Use this for initialization
	void Start () {
		speed = Random.Range (-5, -1);
		rb = gameObject.GetComponent<Rigidbody2D> ();
		grid = GameObject.Find ("grid");
	}
	
	// Update is called once per frame, just used to set speed
	void Update () {
		rb.velocity = new Vector2(speed,0);
	}

	//handles collisions with the player characters
	void OnTriggerEnter2D(Collider2D coldata){
		string tag = coldata.gameObject.tag;
		if (tag == "Player") {
			grid.SendMessage ("healing", -1);
			Destroy (gameObject);
		} else if ((tag == "attack") && (gameObject.tag == "blue")) {
			Destroy (gameObject);
		}
	}
}
