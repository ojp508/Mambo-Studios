﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class newCombat : MonoBehaviour {
	public GameObject warrior;//1
	public GameObject medic;//2
	public GameObject rogue;//3
	public GameObject mage;//4
	public GameObject scientist;//5
	public GameObject alchemist;//6
	private GameObject moving;
	public Button warbutton;
	public Button medicbutton;
	public Button roguebutton;
	public Button magebutton;
	public Button scibutton;
	public Button alcbutton;
	public Text display;
	private int[,] grid;
	private bool turning;
	private bool listening;
	private int health;
	private bool[] buttons;
	private int[] position;
	// Use this for initialization
	void Start () {
		health = 5;
		turning = false;
		listening = true;
		grid = new int[6, 6] { { 1, 0, 0, 0, 0, 0 }, { 2, 0, 0, 0, 0, 0 }, { 3, 0, 0, 0, 0, 0 }, { 4, 0, 0, 0, 0, 0 }, { 5, 0, 0, 0, 0, 0 }, { 6, 0, 0, 0, 0, 0 } };

		warbutton.onClick.AddListener (warturn);
		medicbutton.onClick.AddListener (medicturn);
		roguebutton.onClick.AddListener (rogueturn);
		magebutton.onClick.AddListener (mageturn);
		scibutton.onClick.AddListener (sciturn);
		alcbutton.onClick.AddListener (alcturn);
	}
	
	// Update is called once per frame
	//In this case it starts a players turn if they press a button to move a character
	void Update () {
		display.text = "Health: " + health;
		if (turning == true) { //removes the players ability to select other characters once they have started their turn
			warbutton.onClick.RemoveAllListeners ();
			medicbutton.onClick.RemoveAllListeners ();
			roguebutton.onClick.RemoveAllListeners ();
			magebutton.onClick.RemoveAllListeners ();
			scibutton.onClick.RemoveAllListeners ();
			alcbutton.onClick.RemoveAllListeners ();
			listening = false;
			if (Input.GetKeyDown("space")){
				turning = false;
				move ("none");
			}
		} else {
			if (listening == false) { //reactivates the players ability to click on characters
				listening = true;
				warbutton.onClick.AddListener (warturn);
				medicbutton.onClick.AddListener (medicturn);
				roguebutton.onClick.AddListener (rogueturn);
				magebutton.onClick.AddListener (mageturn);
				scibutton.onClick.AddListener (sciturn);
				alcbutton.onClick.AddListener (alcturn);
			}
		}
	}
	//Handles the players turn,
	void Turn (int character){
		turning = true;
	}
				// Only move("none") is used
	// move handles the moving of characters, direction of movement and the position that needs to be moved
	// Calls charactercontrol.move to actually move the onscreen sprites
	//In theory a move onto an already occupied square would kill the character currently in that square.
	void move (string direction){
		moving.SendMessage ("move", direction);
		if (direction == "up") {
			grid [position [0] + 1, position [1]] = grid [position [0], position [1]];
			grid[position[0],position[1]] = 0;
		} else if (direction == "down"){
			grid [position [0] - 1, position [1]] = grid [position [0], position [1]];
			grid[position[0],position[1]] = 0;
		} else if (direction == "left"){
			grid [position [0], position [1]-1] = grid [position [0], position [1]];
			grid[position[0],position[1]] = 0;
		} else if (direction == "right"){
			grid [position [0], position [1]+1] = grid [position [0], position [1]];
			grid[position[0],position[1]] = 0;
		}
	}

	//unused
	//Finds the position of a character in the grid returning first is the x coordinate, then the y
	int[] Position(int[,] list, int num){
		for (int i = 0; i < 5; i++) {
			for (int x = 0; x < 5; x++) {
				if (list [i, x] == num) {
					return new int[] {i,x};
				}
			}
		}
		return new int[] {0,0};
	}
	int Checkcontents (int[] position){
		return grid[position[0],position[1]];
	}
	//handles the players health, both gaining and loosing

	public void healing(int gain){
		if (gain > 0) {
			if (health < 5) {
				health = health + gain;
			}
		} else {
			health = health + gain;
		}
		if (health <= 0) {
			SceneManager.LoadScene ("map");
		}
	}
		//listeners for all the character selection button presses
	void warturn(){
		moving = warrior;
		Turn (1);
	}	void medicturn(){
		moving = medic;
		Turn (2);
	}	void rogueturn(){
		moving = rogue;
		Turn (3);
	}   void mageturn(){
		moving = mage;
		Turn (4);
	}	void sciturn(){
		moving = scientist;
		Turn (5);
	}	void alcturn(){
		moving = alchemist;
		Turn (6);
	}
}
