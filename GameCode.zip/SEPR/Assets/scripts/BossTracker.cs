﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BossTracker : MonoBehaviour {
	private bool[] beatenbosses;
	public static BossTracker instance = null;
	void Awake (){
		if (instance == null) {
			instance = this;
		} else if (instance != this) {
			Destroy (this);
		}
	}
	// Use this for initialization
	void Start () {
		DontDestroyOnLoad (gameObject); //This object always exists because the values within must be maintained between scenes.
		beatenbosses = new bool[5] { false, false, false, false,false};
	}
	
	// Geter and seter for the boss bools, called when a boss is beaten and when the player tries to move to a new area.
	public void settrue(int index) {
		//sets a boss to be beaten at a give index
		beatenbosses[index] = true;
	}
	public bool getbool (int index){
		return beatenbosses [index];
	}

	//used to exit the game
	void update(){
		if(Input.GetKey("esc")){
			Application.Quit ();
		}
	}
}
