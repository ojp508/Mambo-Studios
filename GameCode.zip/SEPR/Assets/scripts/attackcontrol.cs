﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class attackcontrol : MonoBehaviour {
	private float time;
	private float wait;
	public int type;
	private GameObject playerxp;
	// Use this for initialization
	void Start () {
		playerxp = GameObject.Find ("playerxp");
		time = Time.time;
	}
	
	// Update is called once per frame
	void Update () {
		wait = playerxp.GetComponent<Xptracker> ().spentxp [type] / 2.5f;
		if (time + wait <= Time.time) {
			Destroy (gameObject);
		}
	}
}
