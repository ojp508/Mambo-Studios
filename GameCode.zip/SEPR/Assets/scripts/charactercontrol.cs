﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class charactercontrol : MonoBehaviour {
	public Sprite Medic;
	public Sprite Warrior;
	public Sprite Scientist;
	public Sprite Rogue;
	public Sprite Alchemist;
	public Sprite Mage;
	public Sprite Scroll;
	public Sprite Book;
	private Sprite[] Spritelist;
	private Button self;
	private SpriteRenderer thisrendered;
	public int selftype;
	private GameObject grid;
	public GameObject warriorattack;
	public GameObject scientistattack;
	public GameObject rogueattack;
	public GameObject alchemistattack;
	public GameObject mageattack;
	public GameObject playerxp;
	// Use this for initialization
	void Start () {
		thisrendered = gameObject.GetComponent<SpriteRenderer> ();
		Spritelist = new Sprite[] { Medic, Warrior, Scientist, Rogue, Alchemist, Mage};
		grid = GameObject.Find ("grid");
		Spriteset ();
	}
	
	// sets the sprite of this character
	public void Spriteset () {
		thisrendered.sprite = Spritelist [selftype];
	}

	// Only move("none") is used
	//Handles the character moving and spawning them in the correct starting position.
	public void move(string direction){
		if (direction == "up") {
			gameObject.transform.Translate (new Vector3 (0, 2.5f, 0));
		} else if (direction == "down") {
			gameObject.transform.Translate (new Vector3 (0, -2.5f, 0));
		} else if (direction == "left") {
			gameObject.transform.Translate (new Vector3 (-2.5f, 0, 0));
		} else if (direction == "right") {
			gameObject.transform.Translate (new Vector3 (2.5f, 0, 0));
		}
		attack ();
	}
	void attack(){
		GameObject attacksprite;
		if (selftype == 0) {
			grid.SendMessage ("healing",playerxp.GetComponent<Xptracker> ().spentxp [2]/5);
		} else if (selftype == 1) {
			attacksprite = Instantiate (warriorattack);
			attacksprite.GetComponent<attackcontrol> ().type = 1;
			attacksprite.transform.position = new Vector2 (gameObject.transform.position.x + 2.5f, 0);
		}else if (selftype == 2) {
			attacksprite = Instantiate (scientistattack);
			attacksprite.GetComponent<attackcontrol> ().type = 3;
			attacksprite.transform.position = new Vector2 (0, 0);
		}else if (selftype == 3) {
			attacksprite = Instantiate (rogueattack);
			attacksprite.GetComponent<attackcontrol> ().type = 4;
			attacksprite.transform.position = new Vector2 (5, 0);
		}else if (selftype == 4) {
			attacksprite = Instantiate (alchemistattack);
			attacksprite.GetComponent<attackcontrol> ().type = 5;
			attacksprite.transform.position = new Vector2 (0,6.6f);
		}else if (selftype == 5) {
			attacksprite = Instantiate (mageattack);
			attacksprite.GetComponent<attackcontrol> ().type = 6;
			attacksprite.transform.position = new Vector2 (0, -6.6f);
		}
	}
}
