﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Playermove : MonoBehaviour {
	private float hspeed;
	public float speed;
	private Rigidbody2D rb;
	private int spawnchance;
	public GameObject Roomcontroler;
	private bool door;
	// Use this for initialization
	void Start () {
		Roomcontroler = GameObject.Find ("roomcontrol(Clone)");
		rb = gameObject.GetComponent<Rigidbody2D> ();
	}
	
	// used to move rooms and interact with other objects
	void OnTriggerStay2D (Collider2D collisionInfo) {
		if (Input.GetKey ("w")) {
			string other = collisionInfo.gameObject.tag;
			if (other == "shop"){ 
				//start shop
				print("Shop");
			} else{
			print (other);
			Roomcontroler.SendMessage ("move", other);
			}
		} 
	}
		
	//physics stuff
	void FixedUpdate (){
		hspeed = Input.GetAxis ("Horizontal");
		rb.velocity = new Vector2 (hspeed * speed, 0);
	}
}