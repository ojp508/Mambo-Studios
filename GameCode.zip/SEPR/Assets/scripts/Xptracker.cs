﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Xptracker : MonoBehaviour {
	public int[] spentxp;
	private int gain;
	public static Xptracker instance = null;
	private GameObject bosstracker;
	public GameObject grid;
	public GameObject grid2;
	public Text combatoutput;
	public Button warbutton;
	public Button medicbutton;
	public Button roguebutton;
	public Button magebutton;
	public Button scibutton;
	public Button alcbutton;
	private int decision;
	private int bossbeaten;
	//makes sure there is only ever 1 of this game object
	void Awake (){
		if (instance == null) {
			instance = this;
		} else if (instance != this) {
			Destroy (this);
		}
	}
	// Use this for initialization
	void Start () {
		bossbeaten = 0;
		bosstracker = GameObject.Find("Boss tracker");
		decision = 0;
		DontDestroyOnLoad (gameObject);
		gain = 5;
		spentxp = new int[] {0, 5, 5, 5, 5, 5, 5 }; // a 0 is added at the start of the list so future indexing is easier
	}

	
	//handles the player leveling up at the end of the encounter
	//Levels into non-medics will increase how long their attacks stay on screen
	//levels into medic will increase how big a heal the player gets when the medic heals them
	public void levelfinish () {
		if (bosstracker.GetComponent<BossTracker>().getbool(bossbeaten)){ //makes sure you can't level this up by repeating bosses
			bosstracker.SendMessage ("settrue", bossbeaten); //this tracks which boss has just been beaten
			bossbeaten +=1;
		}
		Destroy (grid);
		Destroy (grid2);
		warbutton.onClick.AddListener (wardi);
		medicbutton.onClick.AddListener (medicdi);
		roguebutton.onClick.AddListener (roguedi);
		magebutton.onClick.AddListener (magedi);
		scibutton.onClick.AddListener (scidi);
		alcbutton.onClick.AddListener (aldi);
		combatoutput.text = "Enemy Defeated, Choose who to level up";
	}
	void wardi(){
		spentxp [1] += gain;
		SceneManager.LoadScene ("map");
	}
	void medicdi(){
		spentxp [1] += gain;
		SceneManager.LoadScene ("map");
	}
	void roguedi(){
		spentxp [1] += gain;
		SceneManager.LoadScene ("map");
	}
	void magedi(){
		spentxp [1] += gain;
		SceneManager.LoadScene ("map");
	}
	void scidi(){
		spentxp [1] += gain;
		SceneManager.LoadScene ("map");
	}
	void aldi(){
		spentxp [1] += gain;
		SceneManager.LoadScene ("map");
	}
}
