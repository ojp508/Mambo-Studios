﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class RoomControler : MonoBehaviour {
	private int[] Dungeon;
	private int position;
	private int type;
	private string roomtype;
	private GameObject roomcontrol;
	public GameObject player;
	public static RoomControler instance = null;
	void Awake (){
		if (instance == null) {
			instance = this;
		} else if (instance != this) {
			Destroy (this);
		}
	}
	// Use this for initialization
	void Start () {
		roomcontrol = this.gameObject;
		GameObject.DontDestroyOnLoad (gameObject);
	}
	//called when the player enters a door

	public void move(string direction){
		if (position * 2 >= Dungeon.Length) {
			SceneManager.LoadScene ("combat");
		}
		if (direction == "downward") {
			position = 0;
			moveroom (); //allows the player to move into the dungeon
		} else if (direction == "up") {
			exitdungeon ();
		}else if (position != 0) {	
			if (direction == "back") {
				position = Mathf.FloorToInt (position / 2);
				moveroom ();
			} else if (direction == "left") {
				position = position * 2; 
				moveroom ();
			} else if (direction == "right") {
				if ((Dungeon [position * 2] != 1) && (Dungeon [position * 2] != 2) && (Dungeon [position * 2] != 3)) {  
					position = position * 2;
					moveroom ();
				} else {
					position = position * 2 + 1;
					moveroom ();
				}
			}
		} else {
			if (direction == "back") {
				exitdungeon ();
			} else if (direction == "left") {
				position = 1;
				moveroom ();
			} else if (direction == "right") {
				position = 2;
				moveroom ();
			}
		}
	}
	
	// loads the new room the player is moving into
	private void moveroom () {
		if (Dungeon [position] == 2) {
			SceneManager.LoadScene ("combat");
		}else if ((Dungeon[position] == 1) || (Dungeon[position] == 3)){
			if ((Dungeon[position*2] != 0) && (Dungeon[position*2 +1] != 0)){
				roomtype = "tjunction" + type;	
			} else {
				roomtype = "corridor" + type;
			}
		}
		SceneManager.LoadScene (roomtype, LoadSceneMode.Single);
	}
	public void settype (int area){
		type = area;
	}
	public void setdungeon (int[] tree){
		Dungeon = tree;
		for (int index = 0; index < Dungeon.Length; index++) {
			print (Dungeon [index]);
		}
	}
	void exitdungeon (){
		SceneManager.LoadScene("Map",LoadSceneMode.Single);
	}
}


