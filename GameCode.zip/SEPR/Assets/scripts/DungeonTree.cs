﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DungeonTree : MonoBehaviour {
	private int goal;
	private int depth;
	private int[] Tree;
	private int[] Gentree;
	private GameObject roomcontrol;
	private int numrooms; // the number of times the randomiser inserts, not necisaarily the number of rooms
	// Use this for initialization
	// 1 means a room, 2 means boss, 3 means exit
	void Start () {
		roomcontrol = this.gameObject;
		depth = 10;
		numrooms = 5;
		Tree = randomtree (numrooms);
		roomcontrol.SendMessage ("setdungeon", Tree);
		print (Tree);
	}
	/// randomly generates the tree by placing nodes in the array
	int[] randomtree (int numrooms){
		Gentree = new int[depth];
		Gentree [0] =3;
		for (int i = 0; i < numrooms; i++){
			int x = Mathf.FloorToInt (Random.Range (0, Gentree.Length));
			if ((Gentree[x] != 1) && (Gentree[x] != 2) && (Gentree[x] != 3)) {
				Gentree[x] = 1;
				connect(x);
			}
		}
		//now determines which room to be the goal
		int y = Mathf.FloorToInt (Random.Range (0, Gentree.Length));
		Gentree[y] = 2;
		connect(y);
		return Gentree;
	}
	void connect (int x)
	{
		if ((Gentree[x] != 1) && (Gentree[x] != 2) && (Gentree[x] != 3)) {
			Gentree [Mathf.FloorToInt (x / 2)] = 1;
			connect (Mathf.FloorToInt (x / 2));
		} 
	}
	public int[] getTree ()
	{
		return Tree;
	}
}
