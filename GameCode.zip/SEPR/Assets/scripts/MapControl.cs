﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class MapControl : MonoBehaviour {
	public Button Button1;
	public Button Button2;
	public Button Button3;
	public Button Button4;
	public Button Button5;
	public Button Shop;
	public GameObject RoomControlPrefab;
	private GameObject RoomControl;
	public GameObject BossTracker;
	public BossTracker BossScript;
	// Use this for initialization
	void Start () {
		RoomControl = GameObject.Find ("roomcontrol");
		BossTracker = GameObject.Find ("Boss tracker");
		BossScript = BossTracker.GetComponent<BossTracker>();
		Destroy (RoomControl);
		//setting up the buttons for moving into areas.
		Button area1 = Button1.GetComponent<Button> ();
		area1.onClick.AddListener (LoadArea1);
		Button area2 = Button2.GetComponent<Button> ();
		area2.onClick.AddListener (LoadArea2);
		Button area3 = Button3.GetComponent<Button> ();
		area3.onClick.AddListener (LoadArea3);
		Button area4 = Button4.GetComponent<Button> ();
		area4.onClick.AddListener (LoadArea4);
		Button area5 = Button5.GetComponent<Button> ();
		area5.onClick.AddListener (LoadArea5);
		//setting up the shop button
		Button shopbtn = Shop.GetComponent<Button>();
		shopbtn.onClick.AddListener (LoadShop);
	}
	// This code loads each of the dungeon areas
	void LoadArea1 () {
		RoomControl = Instantiate (RoomControlPrefab);
		RoomControl.SendMessage ("settype", 1);
		SceneManager.LoadScene ("DungeonEntrance");
	}
	void LoadArea2 () {
			RoomControl = Instantiate (RoomControlPrefab);
			RoomControl.SendMessage ("settype", 2);
			SceneManager.LoadScene ("DungeonEntrance");
	}
	void LoadArea3 () {
			RoomControl = Instantiate (RoomControlPrefab);
			RoomControl.SendMessage ("settype", 3);
			SceneManager.LoadScene ("DungeonEntrance");
	}
	void LoadArea4 () {
			RoomControl =Instantiate (RoomControlPrefab);
			RoomControl.SendMessage ("settype", 4);
			SceneManager.LoadScene ("DungeonEntrance");
	}
	void LoadArea5 () {
			RoomControl =Instantiate (RoomControlPrefab);
			RoomControl.SendMessage ("settype", 5);
			SceneManager.LoadScene ("DungeonEntrance");
	}
	void LoadShop (){
		RoomControl =Instantiate (RoomControlPrefab);
		SceneManager.LoadScene ("Market");
	}
}
