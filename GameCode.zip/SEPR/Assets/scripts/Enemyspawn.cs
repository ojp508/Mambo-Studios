﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemyspawn : MonoBehaviour {
	public GameObject enemyred;
	public GameObject enemyblue;
	public GameObject book;
	public GameObject book2;
	private GameObject enemy;
	private int numenemies;
	private float time;
	private float counter;
	public GameObject playerxp;
	// Use this for initialization
	void Start () {
		playerxp = GameObject.Find ("playerxp");
		time = 0;
		counter = 0.1f;
		numenemies = Mathf.FloorToInt (Random.Range (10, 20));
	}
	
	// Update is called once per frame, spawning enemies based on a counter, keeps spawning till
	void Update () {
		if (numenemies > 0) {
			if (Time.time >= time) {
				numenemies = numenemies - 1;
				time = Time.time + counter;
				int type = Mathf.FloorToInt (Random.Range (0, 4));
				if (type == 0) {
					enemy = Instantiate (enemyred);
				} else if (type == 1) {
					enemy = Instantiate (enemyblue);
				} else if (type == 2) {
					enemy = Instantiate (book);
				} else {
					enemy = Instantiate (book2);
				}
				float ypos = 2.5f * Mathf.FloorToInt (Random.Range (-3, 3)); 
				enemy.transform.position = new Vector2 (15, ypos);
			}
		} else if (GameObject.FindGameObjectsWithTag("blue").Length <= 0){
			playerxp.GetComponent<Xptracker>().levelfinish();
		}
	}
}
