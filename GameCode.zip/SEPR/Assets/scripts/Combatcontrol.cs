﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Combatcontrol : MonoBehaviour {
	private int[,] grid; // 1 to 6 for each character 7,8 and 9 for enemies, 0 for empty space
	private int[] position; // for the purposes of checking neighbours this tells the current characters position
	private int numEnemies;
	public GameObject character1;
	public GameObject character2;
	public GameObject character3;
	public GameObject character4;
	public GameObject character5;
	public GameObject character6;
	public Text combatoutput;
	public InputField combatinput;
	private string input;
	private int inputint;
	private bool turning;
	private int health;

	void Start () {
		health = 6;
		turning = false;
		grid = new int[6,6] { { 1, 0, 0, 0, 0, 0 }, {2, 0, 0, 0, 0, 0 }, { 3, 0, 0, 0, 0, 0}, { 4, 0, 0, 0, 0, 0 }, { 5, 0, 0, 0, 0, 0 }, { 6, 0, 0, 0, 0, 0 }, };
	}
	void update(){
		if (turning == false) {
			StartCoroutine ("turn");
		}
		if (health <= 0) {
			SceneManager.LoadScene ("Map");
		}
		GameObject[] attacks = GameObject.FindGameObjectsWithTag("attack");
		for (int index = 0; index < attacks.Length; index++) {
			Destroy(attacks[index]);
		}
	}

	// this drives the combat loop, setting the output text etc.
	//Turn is a coroutine so it can wait for player input
	IEnumerator turn(){
		turning = true;
			combatinput.ActivateInputField ();
			bool correct = false;
			while (correct == false) {
				yield return StartCoroutine (WaitForEnter());
				input = combatoutput.text;
			if ((input == 1.ToString()) || (input == 2.ToString()) || (input ==3.ToString())|| (input ==4.ToString())|| (input ==5.ToString())|| (input ==6.ToString())) {
					correct = true;
				}
				if (input == 1.ToString ()) {
					inputint = 1;
				} else if (input == 2.ToString ()) {
					inputint = 2;
				} else if (input == 3.ToString ()) {
					inputint = 3;
			}else if (input == 4.ToString ()) {
				inputint = 4;
			}
			else if (input == 5.ToString ()) {
				inputint = 5;
			}
			else if (input == 6.ToString ()) {
				inputint = 6;
			}
			}
			position = Position (grid,inputint );
			string[] moveable = new string[4] {"","","",""}; //Ordered: Up, Down, Left, Right
			//this checks the adjacent squares to see where the player can move, first checking if the position is at the edge of the grid
			//then checking remaining spaces for other players
			if (position [0] == 0) {
				if (position [1] == 0) {
					if (Checkcontents (new int[] { position [0] + 1, position [1] }) == 0) {
						moveable [1] = "down";
					}
					if (Checkcontents (new int[] { position [0], position [1] + 1 }) == 0) {
						moveable [3] = "right";
					}
				} else if (position [1] == 5)
				if (Checkcontents (new int[] { position [0] + 1, position [1] }) == 0) {
					moveable [1] = "down";
				}
				if (Checkcontents (new int[] { position [0], position [1] - 1 }) == 0) {
					moveable [3] = "left";
				}
			} else if (position [0] == 5) {
				if (position [1] == 0) {
					if (Checkcontents (new int[] { position [0] - 1, position [1] }) == 0) {
						moveable [1] = "up";
					}
					if (Checkcontents (new int[] { position [0], position [1] + 1 }) == 0) {
						moveable [3] = "right";
					}
				} else if (position [1] == 5)
				if (Checkcontents (new int[] { position [0] - 1, position [1] }) == 0) {
					moveable [1] = "up";
				}
				if (Checkcontents (new int[] { position [0], position [1] - 1 }) == 0) {
					moveable [3] = "left";
				}

			}
			//this section of code controls getting the users move input it
			correct = false;
			while (correct == false) {
				combatinput.text = "You may move: " + moveable [0] + " " + moveable [1] + " " + moveable [2] + " " + moveable [3];
				yield return StartCoroutine (WaitForEnter());
				input = combatoutput.text;
				if (input == moveable [0]) {
					correct = true;
					move (moveable [0], position);
				} else if (input == moveable [1]) {
					correct = true;
					move (moveable [1], position);
				} else if (input == moveable [2]) {
					correct = true;
					move (moveable [2], position);
				} if (input == moveable [3]) {
					correct = true;
					move (moveable [3], position);
				}
			}
			
	}

	// move handles the moving of characters, direction of movement and the position that needs to be moved
	// Calls charactercontrol.move to actually move the onscreen sprites
	//In theory a move onto an already occupied square would kill the character currently in that square.
	void move (string direction, int[] position){
		string charactername = ("character" + grid [position [0], position [1]]);
		GameObject moving = GameObject.Find (charactername);
		moving.SendMessage ("move", direction);
		if (direction == "up") {
			grid [position [0] + 1, position [1]] = grid [position [0], position [1]];
			grid[position[0],position[1]] = 0;
		} else if (direction == "down"){
			grid [position [0] - 1, position [1]] = grid [position [0], position [1]];
			grid[position[0],position[1]] = 0;
		} else if (direction == "left"){
			grid [position [0], position [1]-1] = grid [position [0], position [1]];
			grid[position[0],position[1]] = 0;
		} else if (direction == "right"){
			grid [position [0], position [1]+1] = grid [position [0], position [1]];
			grid[position[0],position[1]] = 0;
		} else if (direction == "start1") {
			grid [0, 0] = grid [position [0], position [1]];
			grid[position[0],position[1]] = 0;
		} else if (direction == "start2") {
			grid [1,0] = grid [position [0], position [1]];
			grid[position[0],position[1]] = 0;
		} else if (direction == "start3") {
			grid [2, 0] = grid [position [0], position [1]];
			grid[position[0],position[1]] = 0;
		} else if (direction == "start4") {
			grid [0, 5] = grid [position [0], position [1]];
			grid[position[0],position[1]] = 0;
		} else if (direction == "start5") {
			grid [1, 5] = grid [position [0], position [1]];
			grid[position[0],position[1]] = 0;
		} else if (direction == "start6") {
			grid [2, 5] = grid [position [0], position [1]];
			grid[position[0],position[1]] = 0;
		}
	}
	// Searches through the list of a specific number, created to save space in turn()
	bool Contains(int[,] list, int num){
		for (int i = 0; i <5; i++) {
			for(int x = 0;x <5; x++){
				if (list [i,x] == num) {
					return true;
				}
			}
		}
		return false;
	}
	//Finds the position of a character in the grid returning first is the x coordinate, then the y
	int[] Position(int[,] list, int num){
		for (int i = 0; i < 5; i++) {
			for (int x = 0; x < 5; x++) {
				if (list [i, x] == num) {
					return new int[] {x,i};
				}
			}
		}
		return new int[] {0,0};
	}
	int Checkcontents (int[] position){
		return grid[position[0],position[1]];
	}
	//handles the players health, both gaining and loosing

	public void healing(int gain){
		if (gain > 0) {
			if (health < 5) {
				health = health + gain;
			}
		} else {
			health = health + gain;
		}
	}

	//Handles waiting for input using coroutines
	IEnumerator WaitForEnter (){
		while (!Input.GetKeyDown("Enter")){
			yield return null;
		}
	}
}
